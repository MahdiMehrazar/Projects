Controls:

WASD or Arrow Keys for movement (left, right, jump and crouch)
Spacebar for rolling attack

Support for 360 controller is included, haven't tested with other controllers. Movement is with analog, A is jump, B is crouch, right bumper is rolling attack

A few notes:

-There's a checkpoint before the boss battle.

-The player character and environment art (which is just the white blocks) were default Unity assets. Everything else was sprited by myself.

-The ledge grabbing and climbing animations look very wonky due to lack of available sprites.




Mahdi Mehrazar
mahdi0993@gmail.com